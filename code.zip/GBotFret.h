#ifndef GBOT_FRET_H
#define GBOT_FRET_H

#define DISABLE_SERIAL 0

#include "GuitarTrack.h"

#endif